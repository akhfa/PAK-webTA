<div class="f_bg">
    <div class="wrap">
        <div class="footer">
            <div class="f_logo">
                <a href=""><img width="400" height="40" src="<?php echo base_url() ?>images/logo.png" alt=""></a>
                <div class="copy">
                    <p class="w3-link">© All Rights Reserved | Design by&nbsp; <a href="http://w3layouts.com/"> W3Layouts</a></p>
                </div>
            </div>
            <div class="f_grid">
                <div class="social">
                    <ul class="follow_icon">
                        <li><a href="#" style="opacity: 1;">Get Updates Via</a></li>
                        <li><a href="#" style="opacity: 1;"><img src="<?php echo base_url() ?>images/fb.png" alt=""></a></li>
                        <li><a href="#" style="opacity: 1;"><img src="<?php echo base_url() ?>images/g+.png" alt=""></a></li>
                        <li><a href="#" style="opacity: 1;"><img src="<?php echo base_url() ?>images/tw.png" alt=""></a></li>
                        <li><a href="#" style="opacity: 1;"><img src="<?php echo base_url() ?>images/rss.png" alt=""></a></li>
                    </ul>
                </div>
            </div>
            <div class="f_grid1">
                <div class="f_icon">
                    <img src="<?php echo base_url() ?>images/f_icon.png" alt="" />
                </div>
                <div class="f_address">
                    <p>Indonesian Student Research</p>
                    <p>Institute Teknologi Bandung</p>
                    <p>Jl. Ganesha No.10, Bandung, Jawa Barat 40132</p>
                    <p>Telepon: (022) 2500935</p>
                    <p>Email: <span>info@itb.ac.id</span></p>
                </div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
</div>